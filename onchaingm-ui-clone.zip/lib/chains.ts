export type ChainInfo = {
  id: number;
  name: string;
  symbol: string;
  logo?: string;
  testnet?: boolean;
};

export const CHAINS: ChainInfo[] = [
  { id: 8453, name: "Base", symbol: "ETH" },
  { id: 10, name: "Optimism", symbol: "ETH" },
  { id: 42161, name: "Arbitrum", symbol: "ETH" },
  { id: 137, name: "Polygon", symbol: "MATIC" },
  { id: 56, name: "BNB Chain", symbol: "BNB" },
  { id: 1, name: "Ethereum", symbol: "ETH" },
  { id: 59144, name: "Linea", symbol: "ETH" },
  { id: 534352, name: "Scroll", symbol: "ETH" },
  { id: 84532, name: "Base Sepolia", symbol: "ETH", testnet: true },
  { id: 11155111, name: "Ethereum Sepolia", symbol: "ETH", testnet: true },
];
