import { Card } from "@/components/ui";

export default function DocsPage() {
  return (
    <div className="py-10 space-y-6">
      <h1 className="text-3xl font-semibold">Docs</h1>
      <Card className="p-6 space-y-4">
        <p className="text-muted">
          This is a clean-room UI that mimics the look & flow of OnChainGM for educational purposes.
          No proprietary code or assets are included. Replace copy and logos with your own branding
          before publishing. Wire up your web3 logic using wagmi/viem or your preferred toolkit.
        </p>
        <ul className="list-disc pl-5 text-sm text-muted space-y-1">
          <li>Add wallet connection (e.g., wagmi + RainbowKit).</li>
          <li>Implement per-chain GM posting logic.</li>
          <li>Hook leaderboards and feeds to your indexer or subgraph.</li>
          <li>Secure deploy actions (server routes + onchain verification).</li>
        </ul>
      </Card>
    </div>
  );
}
