export default function Support() {
  return (
    <div className="py-10 space-y-4">
      <h1 className="text-3xl font-semibold">Support</h1>
      <p className="text-muted">Add FAQs, contact links, and docs here.</p>
    </div>
  );
}
