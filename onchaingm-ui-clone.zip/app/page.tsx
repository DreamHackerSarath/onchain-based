import StatsCards from "@/components/StatsCards";
import ChainGrid from "@/components/ChainGrid";
import { Button, Card } from "@/components/ui";
import { ArrowRight } from "lucide-react";
import Link from "next/link";

export default function Home() {
  return (
    <div className="py-10 space-y-10">
      <section className="grid lg:grid-cols-2 gap-8 items-center">
        <div className="space-y-6">
          <div className="inline-flex items-center gap-2 badge">Your daily onchain ritual</div>
          <h1 className="text-4xl md:text-5xl font-semibold leading-tight">
            Say <span className="text-brand">GM</span>. Keep a streak. Live on‑chain.
          </h1>
          <p className="text-muted max-w-xl">
            A polished UI inspired by OnChainGM — rebuilt from scratch with Next.js + Tailwind (no copied assets).
          </p>
          <div className="flex gap-3">
            <Link href="/gm" className="btn btn-primary">
              Send a GM <ArrowRight className="ml-2 h-4 w-4" />
            </Link>
            <Link href="/deploy" className="btn btn-ghost">Deploy</Link>
          </div>
          <StatsCards />
        </div>
        <Card className="p-6">
          <div className="text-sm text-muted mb-3">Popular Networks</div>
          <ChainGrid />
        </Card>
      </section>

      <section className="grid md:grid-cols-3 gap-6">
        {[
          { title: "Multi‑chain", desc: "Browse EVM networks and post your GM on any of them." },
          { title: "Streaks", desc: "One GM per 24h per address. Keep your streak alive." },
          { title: "Deploy", desc: "UI for deploying the GM contract — wire up your own logic." }
        ].map((f) => (
          <Card key={f.title} className="p-6">
            <div className="text-lg font-medium mb-1">{f.title}</div>
            <div className="text-muted text-sm">{f.desc}</div>
          </Card>
        ))}
      </section>
    </div>
  );
}
