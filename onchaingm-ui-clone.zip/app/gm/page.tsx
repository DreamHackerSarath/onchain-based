import GMComposer from "@/components/GMComposer";
import StreakHeatmap from "@/components/StreakHeatmap";
import { Card } from "@/components/ui";

export default function GMPage() {
  return (
    <div className="py-10 space-y-8">
      <h1 className="text-3xl font-semibold">Send GM</h1>
      <GMComposer />
      <Card className="p-5">
        <div className="text-sm text-muted mb-4">Your streak calendar</div>
        <StreakHeatmap />
      </Card>
    </div>
  );
}
