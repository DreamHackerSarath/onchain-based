import { Card } from "@/components/ui";

const feed = Array.from({ length: 8 }).map((_, i) => ({
  id: i,
  address: `0x12...${(3456 + i)}`,
  chain: ["Base","OP","Arbitrum","Polygon"][i % 4],
  text: ["GM ☀️","gm frens","GM world","gm wagmi"][i % 4],
  time: `${1 + i}h ago`
}));

export default function FeedPage() {
  return (
    <div className="py-10 space-y-6">
      <h1 className="text-3xl font-semibold">Global Feed</h1>
      <div className="grid sm:grid-cols-2 lg:grid-cols-3 gap-4">
        {feed.map((p) => (
          <Card key={p.id} className="p-4 space-y-3">
            <div className="flex items-center justify-between">
              <div className="text-sm font-mono">{p.address}</div>
              <div className="badge">{p.chain}</div>
            </div>
            <div className="text-lg">{p.text}</div>
            <div className="text-xs text-muted">{p.time}</div>
          </Card>
        ))}
      </div>
    </div>
  );
}
