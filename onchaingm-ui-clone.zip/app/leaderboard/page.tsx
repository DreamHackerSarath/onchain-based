import LeaderboardTable from "@/components/LeaderboardTable";

export default function LeaderboardPage() {
  return (
    <div className="py-10 space-y-6">
      <h1 className="text-3xl font-semibold">Leaderboard</h1>
      <LeaderboardTable />
    </div>
  );
}
