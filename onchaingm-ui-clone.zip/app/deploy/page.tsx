import DeployForm from "@/components/DeployForm";

export default function DeployPage() {
  return (
    <div className="py-10 space-y-6">
      <h1 className="text-3xl font-semibold">Deploy</h1>
      <DeployForm />
    </div>
  );
}
