import "./globals.css";
import type { ReactNode } from "react";
import Navbar from "@/components/Navbar";
import Footer from "@/components/Footer";

export const metadata = {
  title: "GM Onchain — UI Clone",
  description: "A clean-room UI inspired by OnChainGM (no proprietary assets)."
};

export default function RootLayout({ children }: { children: ReactNode }) {
  return (
    <html lang="en">
      <body>
        <Navbar />
        <main className="container-tight">{children}</main>
        <Footer />
      </body>
    </html>
  );
}
