import { Card } from "./ui";

export default function StatsCards() {
  const stats = [
    { label: "Networks", value: "70+" },
    { label: "Users", value: "100K+" },
    { label: "GMs Sent", value: "1M+" }
  ];
  return (
    <div className="grid grid-cols-1 sm:grid-cols-3 gap-4">
      {stats.map((s) => (
        <Card key={s.label} className="stat">
          <div className="label">{s.label}</div>
          <div className="value">{s.value}</div>
        </Card>
      ))}
    </div>
  );
}
