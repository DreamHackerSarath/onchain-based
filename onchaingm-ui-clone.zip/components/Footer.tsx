import Link from "next/link";

export default function Footer() {
  return (
    <footer className="mt-20 border-t border-white/10">
      <div className="container-tight py-10 flex flex-col md:flex-row items-center justify-between gap-6">
        <div className="flex items-center gap-3">
          <img src="/logo.svg" className="h-8 w-8 rounded-xl" alt="logo"/>
          <div className="text-sm text-muted">© {new Date().getFullYear()} GM Onchain — UI clone (clean-room)</div>
        </div>
        <div className="flex gap-5 text-sm text-muted">
          <Link href="/docs" className="hover:text-white">Docs</Link>
          <Link href="/support" className="hover:text-white">Support</Link>
          <a href="https://github.com" className="hover:text-white" target="_blank">GitHub</a>
        </div>
      </div>
    </footer>
  );
}
