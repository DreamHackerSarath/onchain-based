export default function StreakHeatmap() {
  const days = Array.from({ length: 7 * 12 }, (_, i) => i); // 12 weeks
  return (
    <div className="grid grid-cols-12 gap-1">
      {days.map((i) => {
        const level = i % 5;
        const bg = ["bg-white/5","bg-brand/10","bg-brand/20","bg-brand/40","bg-brand/60"][level];
        return <div key={i} className={`w-4 h-4 rounded ${bg} border border-white/10`} />;
      })}
    </div>
  );
}
