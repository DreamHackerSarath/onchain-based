"use client";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { Button } from "./ui";
import { Wallet, Rocket, Send, Trophy, BookText, Rss } from "lucide-react";
import clsx from "clsx";

const nav = [
  { href: "/", label: "Home", icon: Rocket },
  { href: "/feed", label: "Feed", icon: Rss },
  { href: "/gm", label: "Send GM", icon: Send },
  { href: "/leaderboard", label: "Leaderboard", icon: Trophy },
  { href: "/deploy", label: "Deploy", icon: Wallet },
  { href: "/docs", label: "Docs", icon: BookText },
];

export default function Navbar() {
  const pathname = usePathname();
  return (
    <div className="sticky top-0 z-50 backdrop-blur supports-[backdrop-filter]:bg-bg/70">
      <div className="container-tight flex items-center justify-between py-4">
        <Link href="/" className="flex items-center gap-3">
          <img src="/logo.svg" alt="logo" className="h-8 w-8 rounded-xl" />
          <span className="font-semibold tracking-tight">GM Onchain</span>
        </Link>
        <nav className="hidden md:flex items-center gap-1">
          {nav.map(({ href, label }) => (
            <Link
              key={href}
              href={href}
              className={clsx(
                "px-3 py-2 rounded-xl text-sm transition border",
                pathname === href
                  ? "bg-white/10 border-white/15"
                  : "border-transparent hover:bg-white/5"
              )}
            >
              {label}
            </Link>
          ))}
        </nav>
        <div className="flex items-center gap-2">
          <Button variant="ghost" className="hidden md:inline-flex">Testnet</Button>
          <Button>Connect Wallet</Button>
        </div>
      </div>
    </div>
  );
}
