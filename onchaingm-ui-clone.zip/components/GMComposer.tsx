"use client";
import { useState } from "react";
import { Button, Textarea } from "./ui";
import { Sparkles } from "lucide-react";

export default function GMComposer() {
  const [text, setText] = useState("GM ☀️");
  return (
    <div className="card p-5 flex flex-col gap-3">
      <div className="flex items-center justify-between">
        <div className="font-medium">Compose your daily GM</div>
        <div className="badge">Streak: 3 days</div>
      </div>
      <Textarea
        value={text}
        onChange={(e:any) => setText(e.target.value)}
        placeholder="Write a friendly GM to the chain..."
      />
      <div className="flex items-center justify-between">
        <div className="text-xs text-muted">One GM per 24h per address.</div>
        <Button disabled onClick={() => {}}>
          <Sparkles className="mr-2 h-4 w-4" /> Send GM
        </Button>
      </div>
    </div>
  );
}
