export default function LeaderboardTable() {
  const rows = new Array(10).fill(0).map((_, i) => ({
    rank: i + 1,
    address: `0xABCD...${(1000 + i)}`,
    gms: 42 - i,
    streak: 7 + i
  }));
  return (
    <div className="card p-4 overflow-x-auto">
      <table className="w-full text-sm">
        <thead className="text-left text-muted">
          <tr className="[&>th]:py-2 [&>th]:font-normal">
            <th>Rank</th><th>Address</th><th>GMs</th><th>Streak</th>
          </tr>
        </thead>
        <tbody className="[&>tr]:border-t [&>tr]:border-white/10">
          {rows.map(r => (
            <tr key={r.rank} className="[&>td]:py-3">
              <td>#{r.rank}</td>
              <td className="font-mono">{r.address}</td>
              <td>{r.gms}</td>
              <td>{r.streak} days</td>
            </tr>
          ))}
        </tbody>
      </table>
    </div>
  );
}
