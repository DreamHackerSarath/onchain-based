import { Button, Input, Select } from "./ui";
import { CHAINS } from "@/lib/chains";
import { Check } from "lucide-react";

export default function DeployForm() {
  return (
    <div className="grid md:grid-cols-2 gap-6">
      <div className="card p-5 space-y-4">
        <div className="font-medium text-lg">Deploy Contract (UI only)</div>
        <label className="block text-sm text-muted">Network</label>
        <Select>
          {CHAINS.map(c => <option key={c.id} value={c.id}>{c.name}{c.testnet ? " (Testnet)" : ""}</option>)}
        </Select>
        <label className="block text-sm text-muted mt-2">Contract Name</label>
        <Input placeholder="GMMachine" />
        <label className="block text-sm text-muted mt-2">Owner Address</label>
        <Input placeholder="0x..." />
        <div className="flex items-center gap-3 pt-2">
          <Button className="w-full">Deploy</Button>
          <Button variant="ghost" className="w-full">Verify</Button>
        </div>
        <p className="text-xs text-muted">Note: This is a visual clone. Add your own wagmi/viem logic for real deployment.</p>
      </div>
      <div className="card p-5 space-y-3">
        <div className="font-medium">What you get</div>
        <ul className="space-y-2 text-sm text-muted">
          <li className="flex items-center gap-2"><Check className="h-4 w-4 text-brand" /> Clean-room Next.js UI</li>
          <li className="flex items-center gap-2"><Check className="h-4 w-4 text-brand" /> Tailwind + components</li>
          <li className="flex items-center gap-2"><Check className="h-4 w-4 text-brand" /> Pages matching the original flow</li>
        </ul>
      </div>
    </div>
  );
}
