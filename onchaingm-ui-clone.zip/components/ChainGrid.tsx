import { CHAINS } from "@/lib/chains";
import { Card } from "./ui";

export default function ChainGrid() {
  return (
    <div className="grid grid-cols-2 sm:grid-cols-3 md:grid-cols-4 lg:grid-cols-5 gap-3">
      {CHAINS.map((c) => (
        <Card key={c.id} className="p-4 flex items-center justify-between">
          <div className="flex items-center gap-3">
            <div className="h-8 w-8 rounded-xl bg-white/5 border border-white/10" />
            <div>
              <div className="font-medium">{c.name}</div>
              <div className="text-xs text-muted">{c.symbol}{c.testnet ? " · Testnet" : ""}</div>
            </div>
          </div>
          <button className="text-sm text-muted hover:text-white">Open</button>
        </Card>
      ))}
    </div>
  );
}
