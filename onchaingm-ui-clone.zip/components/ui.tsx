import clsx from "clsx";
import { HTMLAttributes, ButtonHTMLAttributes } from "react";

export function Card({ className, ...props }: HTMLAttributes<HTMLDivElement>) {
  return <div className={clsx("card", className)} {...props} />;
}

export function Button({
  className,
  variant = "primary",
  ...props
}: ButtonHTMLAttributes<HTMLButtonElement> & { variant?: "primary" | "ghost" }) {
  const styles = variant === "primary" ? "btn btn-primary" : "btn btn-ghost";
  return <button className={clsx(styles, className)} {...props} />;
}

export function Input({ className, ...props }: HTMLAttributes<HTMLInputElement> & any) {
  return (
    <input
      className={clsx(
        "rounded-xl bg-white/5 border border-white/10 px-4 py-2 outline-none focus:ring-2 focus:ring-brand/40",
        className
      )}
      {...props}
    />
  );
}

export function Select({ className, ...props }: HTMLAttributes<HTMLSelectElement> & any) {
  return (
    <select
      className={clsx(
        "rounded-xl bg-white/5 border border-white/10 px-4 py-2 outline-none focus:ring-2 focus:ring-brand/40",
        className
      )}
      {...props}
    />
  );
}

export function Textarea({ className, ...props }: HTMLAttributes<HTMLTextAreaElement> & any) {
  return (
    <textarea
      className={clsx(
        "rounded-xl bg-white/5 border border-white/10 px-4 py-3 outline-none focus:ring-2 focus:ring-brand/40 min-h-[120px]",
        className
      )}
      {...props}
    />
  );
}
